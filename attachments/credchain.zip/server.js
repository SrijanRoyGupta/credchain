'use strict';
/* CredChain – zero-dependency Node.js blockchain + JavaScript smart contract + API.
   Run: node server.js   → http://localhost:3000   (Node 18+) */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000, DATA = path.join(__dirname, 'data'), PUB = path.join(__dirname, 'public');
const U = 1e6, DAY = 86400000, DIFFICULTY = '000', LOAN_DAYS = 30, MIN_LOAN = 1000 * U;
fs.mkdirSync(DATA, { recursive: true });
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const rd = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(DATA, f))); } catch { return d; } };
const wr = (f, v) => fs.writeFileSync(path.join(DATA, f), JSON.stringify(v, null, 1));
const SECRET = (() => { const p = path.join(DATA, 'secret.key'); if (!fs.existsSync(p)) fs.writeFileSync(p, crypto.randomBytes(32).toString('hex'), { mode: 0o600 }); return fs.readFileSync(p, 'utf8'); })();

/* ───────────── SMART CONTRACT (deterministic; state is rebuilt by replaying the chain) ───────────── */
class CredChainContract {
  constructor() { this.bal = {}; this.pool = 0; this.loans = {}; this.hist = {}; this.faucetAt = {}; this.nonce = {}; }
  h(a) { return this.hist[a] ??= { repaid: 0, largest: 0, defaults: 0 }; }
  // All amounts are in rupees. L = largest repaid principal in ₹ thousands (so min(L,200) caps at ₹2 lakh).
  // S = min(1000, max(0, 300 + 50·min(R,6) + min(L,200) − 150·D))
  score(a) { const { repaid: R, largest: L, defaults: D } = this.h(a); return Math.min(1000, Math.max(0, 300 + 50 * Math.min(R, 6) + Math.min(L, 200) - 150 * D)); }
  terms(a) {
    const s = this.score(a); const t = s < 400 ? [5000, 10000, 2400] : s < 600 ? [20000, 5000, 1800] : s < 800 ? [100000, 2500, 1200] : [200000, 1000, 800];
    return { score: s, maxLoan: t[0] * U, collateralBps: t[1], aprBps: t[2] };
  }
  quote(a, now) {
    const l = this.loans[a]; if (!l) return null;
    const interest = Math.floor(l.principal * l.aprBps / 10000 * Math.max(0, now - l.start) / (365 * DAY));
    return { principal: l.principal, interest, total: l.principal + interest, due: l.due };
  }
  sweepDefaults(now) { // overdue loans: collateral is seized into the pool, default recorded
    for (const [a, l] of Object.entries(this.loans)) if (now > l.due) { this.pool += l.collateral; this.h(a).defaults++; delete this.loans[a]; }
  }
  exec(tx) {
    const { from, action, amount = 0, ts } = tx;
    if (action === 'init') { this.pool = amount; return; }
    if ((this.nonce[from] || 0) !== tx.nonce) throw Error('Bad nonce');
    this.sweepDefaults(ts);
    const b = this.bal[from] || 0;
    if (action !== 'faucet' && action !== 'repay' && !(Number.isInteger(amount) && amount > 0)) throw Error('Invalid amount');
    if (action === 'faucet') {
      if (ts - (this.faucetAt[from] || 0) < DAY) throw Error('Faucet available once every 24 hours');
      this.faucetAt[from] = ts; this.bal[from] = b + 100000 * U;
    } else if (action === 'fundPool') {
      if (b < amount) throw Error('Insufficient balance');
      this.bal[from] = b - amount; this.pool += amount;
    } else if (action === 'borrow') {
      const t = this.terms(from), col = Math.ceil(amount * t.collateralBps / 10000);
      if (this.loans[from]) throw Error('You already have an active loan');
      if (amount < MIN_LOAN) throw Error('Minimum loan is ₹1,000');
      if (amount > t.maxLoan) throw Error('Above your maximum loan');
      if (amount > this.pool) throw Error('Not enough pool liquidity');
      if (b < col) throw Error('Need ₹' + (col / U).toLocaleString('en-IN') + ' collateral in your wallet');
      this.pool -= amount; this.bal[from] = b - col + amount;
      this.loans[from] = { principal: amount, collateral: col, aprBps: t.aprBps, start: ts, due: ts + LOAN_DAYS * DAY };
    } else if (action === 'repay') {
      const l = this.loans[from]; if (!l) throw Error('No active loan');
      const q = this.quote(from, ts); if (b < q.total) throw Error('Need ₹' + (q.total / U).toLocaleString('en-IN') + ' to repay');
      this.bal[from] = b - q.total + l.collateral; this.pool += q.total;
      const h = this.h(from); h.repaid++; h.largest = Math.max(h.largest, Math.floor(l.principal / U / 1000)); delete this.loans[from];
    } else if (action === 'transfer') {
      if (!tx.to || tx.to === from) throw Error('Enter a different wallet address');
      if (b < amount) throw Error('Insufficient balance');
      this.bal[from] = b - amount; this.bal[tx.to] = (this.bal[tx.to] || 0) + amount;
    } else throw Error('Unknown action');
    this.nonce[from] = tx.nonce + 1;
  }
}

/* ───────────── BLOCKCHAIN ───────────── */
class Blockchain {
  constructor() {
    this.wallets = rd('wallets.json', {}); this.blocks = rd('chain.json', []);
    if (!this.blocks.length) this.blocks.push(this.mine(0, '0'.repeat(64), [{ from: 'system', action: 'init', amount: 1000000 * U, ts: Date.now() }]));
    this.rebuild(); this.persist();
  }
  hashBlock(b) { return sha(b.index + b.prev + b.ts + JSON.stringify(b.txs) + b.nonce); }
  mine(index, prev, txs) {
    const b = { index, prev, ts: Date.now(), txs, nonce: 0 };
    while (!(b.hash = this.hashBlock(b)).startsWith(DIFFICULTY)) b.nonce++;
    return b;
  }
  rebuild() { this.sc = new CredChainContract(); for (const b of this.blocks) for (const t of b.txs) this.sc.exec(t); }
  persist() { wr('chain.json', this.blocks); wr('wallets.json', this.wallets); }
  payload(t) { return JSON.stringify([t.from, t.action, t.amount ?? 0, t.nonce, t.ts, t.to ?? '']); }
  submit(address, action, amount, to) { // wallet signs; contract executes on a trial copy; block is mined only on success
    const w = this.wallets[address]; if (!w) throw Error('Unknown wallet');
    const tx = { from: address, action, amount, nonce: this.sc.nonce[address] || 0, ts: Date.now() };
    if (to) tx.to = to;
    tx.sig = crypto.sign('sha256', Buffer.from(this.payload(tx)), w.priv).toString('hex');
    const trial = new CredChainContract(); for (const b of this.blocks) for (const t of b.txs) trial.exec(t); trial.exec(tx);
    const last = this.blocks.at(-1), blk = this.mine(last.index + 1, last.hash, [tx]);
    this.blocks.push(blk); this.sc = trial; this.persist(); return blk;
  }
  validate() {
    for (let i = 0; i < this.blocks.length; i++) {
      const b = this.blocks[i];
      if (b.hash !== this.hashBlock(b) || !b.hash.startsWith(DIFFICULTY)) return { valid: false, at: i };
      if (i && b.prev !== this.blocks[i - 1].hash) return { valid: false, at: i };
      for (const t of b.txs) if (t.from !== 'system') {
        const w = this.wallets[t.from]; if (!w || !crypto.verify('sha256', Buffer.from(this.payload(t)), w.pub, Buffer.from(t.sig, 'hex'))) return { valid: false, at: i };
      }
    }
    return { valid: true, blocks: this.blocks.length };
  }
}
const chain = new Blockchain();

/* ───────────── KYC INPUT VALIDATION ───────────── */
const vd = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]];
const vp = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]];
const verhoeff = n => { let c = 0; [...n].reverse().forEach((x, i) => c = vd[c][vp[i % 8][+x]]); return c === 0; };
const mask = (s, keep = 4) => 'X'.repeat(Math.max(0, s.length - keep)) + s.slice(-keep);
function validateKyc(k) {
  const e = {}, s = v => String(v ?? '').trim();
  const email = s(k.email).toLowerCase(), aadhaar = s(k.aadhaar).replace(/\s/g, ''), bank = s(k.bank), ifsc = s(k.ifsc).toUpperCase(), mobile = s(k.mobile).replace(/^\+?91/, '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) e.email = 'Enter a valid email address';
  if (!/^[2-9]\d{11}$/.test(aadhaar) || !verhoeff(aadhaar)) e.aadhaar = 'Enter a valid 12-digit Aadhaar number';
  if (!/^\d{9,18}$/.test(bank)) e.bank = 'Account number must be 9–18 digits';
  if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) e.ifsc = 'IFSC looks like HDFC0001234';
  if (!/^[6-9]\d{9}$/.test(mobile)) e.mobile = 'Enter a 10-digit Indian mobile number';
  return { e, v: { email, aadhaar, bank, ifsc, mobile } };
}

/* ───────────── HTTP API ───────────── */
const json = (res, code, body) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(body)); };
const body = req => new Promise((ok, no) => { let d = ''; req.on('data', c => { d += c; if (d.length > 1e5) { req.destroy(); no(Error('Too large')); } }); req.on('end', () => { try { ok(d ? JSON.parse(d) : {}); } catch { no(Error('Bad JSON')); } }); });
const auth = req => { const t = req.headers['x-token']; if (!t) return null; const h = sha(t); return Object.values(chain.wallets).find(w => w.tokenHash === h) || null; };
const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' };

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/api/wallet' && req.method === 'POST') {
      const { e, v } = validateKyc(await body(req));
      if (Object.keys(e).length) return json(res, 422, { errors: e });
      const aadhaarHash = crypto.createHmac('sha256', SECRET).update(v.aadhaar).digest('hex');
      if (Object.values(chain.wallets).some(w => w.kyc.aadhaarHash === aadhaarHash)) return json(res, 409, { errors: { aadhaar: 'A wallet already exists for this Aadhaar' } });
      const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'secp256k1' });
      const pub = publicKey.export({ type: 'spki', format: 'pem' }), priv = privateKey.export({ type: 'pkcs8', format: 'pem' });
      const address = '0x' + sha(pub).slice(-40), token = crypto.randomBytes(32).toString('hex');
      // Raw Aadhaar / bank number are NEVER stored: only a keyed hash (dedupe) and a masked display value.
      chain.wallets[address] = { address, pub, priv, tokenHash: sha(token), created: Date.now(),
        kyc: { email: v.email, mobile: mask(v.mobile, 2), aadhaarMasked: mask(v.aadhaar), aadhaarHash, bankMasked: mask(v.bank), ifsc: v.ifsc } };
      chain.persist(); return json(res, 201, { address, token });
    }
    if (url.pathname === '/api/state') {
      const w = auth(req); if (!w) return json(res, 401, { error: 'Not signed in' });
      const sc = chain.sc, a = w.address, now = Date.now();
      return json(res, 200, { address: a, created: w.created, kyc: { email: w.kyc.email, aadhaar: w.kyc.aadhaarMasked, bank: w.kyc.bankMasked, ifsc: w.kyc.ifsc, mobile: w.kyc.mobile },
        balance: sc.bal[a] || 0, pool: sc.pool, terms: sc.terms(a), history: sc.h(a), loan: sc.loans[a] || null, quote: sc.quote(a, now),
        faucetReady: now - (sc.faucetAt[a] || 0) >= DAY, height: chain.blocks.length });
    }
    if (url.pathname === '/api/tx' && req.method === 'POST') {
      const w = auth(req); if (!w) return json(res, 401, { error: 'Not signed in' });
      const { action, amount, to } = await body(req);
      if (action === 'transfer' && !chain.wallets[String(to)]) throw Error('Recipient wallet not found');
      const blk = chain.submit(w.address, String(action), action === 'repay' || action === 'faucet' ? 0 : Math.round(Number(amount) * U), action === 'transfer' ? String(to) : undefined);
      return json(res, 200, { hash: blk.hash, index: blk.index });
    }
    if (url.pathname === '/api/lookup') return json(res, 200, { exists: !!chain.wallets[url.searchParams.get('address')] });
    if (url.pathname === '/api/history') {
      const w = auth(req); if (!w) return json(res, 401, { error: 'Not signed in' });
      const out = []; for (const b of chain.blocks) for (const t of b.txs) if (t.from === w.address || t.to === w.address) out.push({ index: b.index, hash: b.hash, ts: t.ts, action: t.action, amount: t.amount, from: t.from, to: t.to });
      return json(res, 200, out.reverse().slice(0, 50));
    }
    if (url.pathname === '/api/chain') return json(res, 200, { pool: chain.sc.pool, wallets: Object.keys(chain.wallets).length, lastTs: chain.blocks.at(-1).ts, validation: chain.validate(), blocks: chain.blocks.slice(-12).reverse().map(b => ({ index: b.index, hash: b.hash, prev: b.prev, ts: b.ts, nonce: b.nonce, tx: b.txs.map(t => ({ from: t.from, action: t.action, amount: t.amount })) })) });
    // static files
    let f = path.normalize(path.join(PUB, url.pathname === '/' ? 'index.html' : url.pathname));
    if (!f.startsWith(PUB) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' }); fs.createReadStream(f).pipe(res);
  } catch (err) { json(res, 400, { error: err.message }); }
}).listen(PORT, () => console.log(`CredChain running → http://localhost:${PORT}  (chain height ${chain.blocks.length}, valid: ${chain.validate().valid})`));
